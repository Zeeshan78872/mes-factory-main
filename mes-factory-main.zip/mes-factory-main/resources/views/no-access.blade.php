@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">

            <div class="card">
                <div class="card-header">No Access</div>

                <div class="card-body">
                    You do not have access to use this feature. Contact Your Admin to have access to this feature.
                </div>
            </div>

        </div>
    </div>
</div>
@endsection